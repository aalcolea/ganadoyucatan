@include('Tienda.header')
@section('view')


@show
@include('Tienda.footer')
