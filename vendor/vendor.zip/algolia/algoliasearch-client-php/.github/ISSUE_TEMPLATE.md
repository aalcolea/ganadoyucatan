<!--
Please use this issue tracker only for reporting bugs or feature requests.

If you need support, please use:
 
- our community forum
  http://discourse.algolia.com
  
- StackOverflow with the `algolia` tag
  https://stackoverflow.com/questions/tagged/algolia

-->

- Algolia Client Version: #.#.#
- Language Version:

### Description


### Steps To Reproduce
